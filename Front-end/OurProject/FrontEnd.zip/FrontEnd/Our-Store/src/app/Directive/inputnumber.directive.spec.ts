import { InputnumberDirective } from './inputnumber.directive';

describe('InputnumberDirective', () => {
  it('should create an instance', () => {
    const directive = new InputnumberDirective();
    expect(directive).toBeTruthy();
  });
});
