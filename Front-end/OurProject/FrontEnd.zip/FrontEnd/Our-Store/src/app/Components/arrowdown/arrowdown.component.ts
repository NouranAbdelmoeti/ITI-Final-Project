import { Component } from '@angular/core';

@Component({
  selector: 'app-arrowdown',
  standalone: true,
  imports: [],
  templateUrl: './arrowdown.component.html',
  styleUrl: './arrowdown.component.css'
})
export class ArrowdownComponent {

}
